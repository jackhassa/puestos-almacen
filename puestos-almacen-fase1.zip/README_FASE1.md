# Puestos Almacén — FASE 1

Este paquete parte exactamente del ZIP de revisión recibido.

## Cambios de código
- Añade `Montajes` como asignación manual/operativa, sin introducirlo en la rueda teórica.
- Centraliza los códigos/etiquetas operativas en `lib/operational-types.ts`.
- Mantiene la rueda actual Mesa1 → Mesa2 → Mesa3 → Mesa4 → Entradas → Picking.

## Base de datos preparada
- Jornadas operativas.
- Periodos reales de puesto/modo.
- Modos: Carro, Exportación y Apoyo.
- Pausas: Desayuno / Comida / Cena; Fumar / Vapear.
- Terminales PC fijo y RF.
- Credenciales de operario con password hasheado.
- Sesión de terminal recuperable en otro equipo sin cerrar jornada.
- Historial de correcciones inmutable.
- Horarios configurables para cierre automático futuro.
- RPC para login, recuperación de estado, inicio/fin de jornada, cambio de tarea y pausas.

## Instalación
1. Ejecutar `instalar_fase1.ps1`.
2. El instalador crea backup y ejecuta `git diff --check`, `npm run lint` y `npm run build`.
3. Si algo falla, restaura los archivos anteriores.
4. Después aplicar manualmente en Supabase SQL Editor la migración:
   `supabase/migrations/20260903190000_create_warehouse_operations_phase1.sql`
5. Ejecutar `verificar_supabase_fase1.sql`.

No se crea todavía `/terminal`; corresponde a FASE 2.
