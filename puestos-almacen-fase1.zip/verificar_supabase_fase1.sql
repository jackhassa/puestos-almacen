-- Ejecutar en Supabase SQL Editor DESPUES de aplicar la migracion FASE 1.
select
  to_regclass('public.warehouse_terminals') as terminals,
  to_regclass('public.warehouse_employee_credentials') as credentials,
  to_regclass('public.warehouse_terminal_sessions') as terminal_sessions,
  to_regclass('public.warehouse_work_sessions') as work_sessions,
  to_regclass('public.warehouse_work_periods') as work_periods,
  to_regclass('public.warehouse_break_types') as break_types,
  to_regclass('public.warehouse_work_breaks') as work_breaks,
  to_regclass('public.warehouse_shift_schedules') as shift_schedules,
  to_regclass('public.warehouse_corrections') as corrections;

select code, label, active, display_order
from public.warehouse_break_types
order by display_order;

select routine_name
from information_schema.routines
where routine_schema = 'public'
  and routine_name like 'warehouse_%'
order by routine_name;
