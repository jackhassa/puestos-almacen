﻿$ErrorActionPreference = "Stop"

$projectRoot = "C:\Proyectos\puestos-almacen"
$payloadRoot = Join-Path $PSScriptRoot "payload"

if (-not (Test-Path -LiteralPath (Join-Path $projectRoot "package.json") -PathType Leaf)) {
    throw "No se encuentra el proyecto en $projectRoot"
}

$expectedHashes = @{
    "app\hoy\page.tsx" = "D31CB81539FF1C70B7C2B45B9BB8C1B48CDAEBC96C81FF4683AFDBE1C5F7D286"
    "app\monitor\page.tsx" = "28D3FCF3230FBA4FDC471142F87032FB25240CD1B996B1D408D7742CB442E84F"
    "app\planificacion\page.tsx" = "353773DC61E2C39BD21BA729AD2C47BAC06243120749A5EA586EE72F07F76E17"
}

Write-Host "Comprobando que el proyecto sigue igual que el ZIP revisado..." -ForegroundColor Cyan
foreach ($relative in $expectedHashes.Keys) {
    $target = Join-Path $projectRoot $relative
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) {
        throw "Falta el archivo requerido: $target"
    }

    $actual = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($actual -ne $expectedHashes[$relative]) {
        throw "El archivo $relative ha cambiado desde la revisión. No se sobrescribe nada. Vuelve a generar el ZIP de revisión."
    }
}

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupRoot = Join-Path $projectRoot "_backup_fase1_$stamp"
New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

$targets = @(
    "app\hoy\page.tsx",
    "app\monitor\page.tsx",
    "app\planificacion\page.tsx",
    "lib\operational-types.ts",
    "supabase\migrations\20260903190000_create_warehouse_operations_phase1.sql"
)

$existingBefore = @{}

function Restore-Fase1 {
    Write-Host "Restaurando archivos anteriores..." -ForegroundColor Yellow
    foreach ($relative in $targets) {
        $target = Join-Path $projectRoot $relative
        $backup = Join-Path $backupRoot $relative
        if ($existingBefore[$relative]) {
            $targetDir = Split-Path -Parent $target
            if (-not (Test-Path -LiteralPath $targetDir)) { New-Item -ItemType Directory -Path $targetDir -Force | Out-Null }
            Copy-Item -LiteralPath $backup -Destination $target -Force
        } elseif (Test-Path -LiteralPath $target) {
            Remove-Item -LiteralPath $target -Force
        }
    }
}

try {
    foreach ($relative in $targets) {
        $target = Join-Path $projectRoot $relative
        $source = Join-Path $payloadRoot $relative
        $existing = Test-Path -LiteralPath $target -PathType Leaf
        $existingBefore[$relative] = $existing

        if ($existing) {
            $backup = Join-Path $backupRoot $relative
            $backupDir = Split-Path -Parent $backup
            if (-not (Test-Path -LiteralPath $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
            Copy-Item -LiteralPath $target -Destination $backup -Force
        }

        $targetDir = Split-Path -Parent $target
        if (-not (Test-Path -LiteralPath $targetDir)) { New-Item -ItemType Directory -Path $targetDir -Force | Out-Null }
        Copy-Item -LiteralPath $source -Destination $target -Force
    }

    Set-Location $projectRoot

    Write-Host "Ejecutando git diff --check..." -ForegroundColor Cyan
    & git diff --check
    if ($LASTEXITCODE -ne 0) { throw "git diff --check ha fallado." }

    Write-Host "Ejecutando lint..." -ForegroundColor Cyan
    & npm run lint
    if ($LASTEXITCODE -ne 0) { throw "npm run lint ha fallado." }

    Write-Host "Ejecutando build..." -ForegroundColor Cyan
    & npm run build
    if ($LASTEXITCODE -ne 0) { throw "npm run build ha fallado." }

    Write-Host "" 
    Write-Host "FASE 1 instalada en el código y validada." -ForegroundColor Green
    Write-Host "Backup: $backupRoot" -ForegroundColor DarkGray
    Write-Host "" 
    Write-Host "IMPORTANTE: la migración SQL SOLO se ha copiado al proyecto; todavía NO se ha aplicado a Supabase." -ForegroundColor Yellow
    Write-Host "Archivo SQL:" -ForegroundColor Yellow
    Write-Host (Join-Path $projectRoot "supabase\migrations\20260903190000_create_warehouse_operations_phase1.sql")
}
catch {
    Restore-Fase1
    Write-Host "" 
    Write-Host "La instalación se ha revertido porque una comprobación ha fallado." -ForegroundColor Red
    throw
}
